# Compiling Instructions

Navigate to the Project 2 folder within the repository

How to run the file os_project_2.cpp:

1. On a Linux command line, run the following command  
    
```
gcc os_project_2.cpp -lpthread
```

2. Once that is proccessed then run the next following command

```
    ./a.out 1
```

3. Repalce the number one with any  number as that is your random seed number